Fountain Copyright (C) 2016 Evan Llewellyn Price
A map painting/generating software kit for worldbuilders. Fountain.exe and its source code are licenced under the GNU General Public License (found here: http://www.gnu.org/licenses/)

LlewellynScripting Copyright (C) 2016 Evan Llewellyn Price
An auxiliary library for use with Fountain. LlewellynScripting.dll and its source code are licenced under the GNU General Public License (found here: http://www.gnu.org/licenses/)

LlewellynMath Copyright (C) 2016 Evan Llewellyn Price
An auxiliary library for use with Fountain. LlewellynMath.dll and its source code are licenced under the GNU General Public License (found here: http://www.gnu.org/licenses/)

LlewellynMedia Copyright (C) 2016 Evan Llewellyn Price
An auxiliary library for use with Fountain. LlewellynMedia.dll and its source code are licenced under the GNU General Public License (found here: http://www.gnu.org/licenses/)